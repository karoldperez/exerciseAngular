export interface Alert {
  message: string;
  // state: boolean,
  color: string,
}
